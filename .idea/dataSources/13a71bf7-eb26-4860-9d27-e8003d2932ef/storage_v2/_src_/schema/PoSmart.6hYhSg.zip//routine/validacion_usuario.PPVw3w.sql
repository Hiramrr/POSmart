create
    definer = Hiram@`%` procedure validacion_usuario(IN Nombre_User varchar(20), IN Contraseña_user varchar(255))
BEGIN
SELECT *
FROM Usuario
WHERE Nombre_usuario = Nombre_User
  AND Contraseña = Contraseña_user;
END;

