create
    definer = Hiram@`%` procedure existe_usuario(IN Nombre_Com varchar(20))
BEGIN
SELECT Nombre_completo
FROM Usuario
WHERE Nombre_completo = Nombre_Com;
END;

