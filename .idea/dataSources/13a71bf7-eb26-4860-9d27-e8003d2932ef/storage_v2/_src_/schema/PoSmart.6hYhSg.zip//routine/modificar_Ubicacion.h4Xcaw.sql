create
    definer = Hiram@`%` procedure modificar_Ubicacion(IN p_id int, IN p_nombre varchar(255),
                                                      IN p_descripcion varchar(3000))
BEGIN
    UPDATE Ubicacion
    SET Nombre = p_nombre,
        Descripcion = p_descripcion
    WHERE id_Ubicacion = p_id;
END;

