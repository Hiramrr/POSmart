create
    definer = Hiram@`%` procedure eliminar_Ubicacion(IN id int)
BEGIN
    DELETE FROM Ubicacion WHERE id_Ubicacion = id;
END;

