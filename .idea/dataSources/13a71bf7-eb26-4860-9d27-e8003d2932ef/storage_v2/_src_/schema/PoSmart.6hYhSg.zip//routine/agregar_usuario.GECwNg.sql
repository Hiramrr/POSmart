create
    definer = Hiram@`%` procedure agregar_usuario(IN p_id int, IN p_Nombre_usuario varchar(20),
                                                  IN p_Contraseña varchar(50), IN p_Nombre_completo varchar(50),
                                                  IN p_Rol varchar(20), IN p_Telefono varchar(15),
                                                  IN p_Ciudad varchar(30), IN p_Direccion varchar(100))
BEGIN
    INSERT INTO Usuario (id_usuario, Nombre_usuario, Contraseña, Nombre_completo, Rol, Telefono, Ciudad, Direccion)
    VALUES (p_id, p_Nombre_usuario, p_Contraseña, p_Nombre_completo, p_Rol, p_Telefono, p_Ciudad, p_Direccion);
    
    SELECT id_usuario
    FROM Usuario
    WHERE id_usuario = p_id;
END;

