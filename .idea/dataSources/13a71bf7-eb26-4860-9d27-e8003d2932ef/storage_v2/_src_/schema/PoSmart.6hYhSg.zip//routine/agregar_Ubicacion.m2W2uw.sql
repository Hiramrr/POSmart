create
    definer = Hiram@`%` procedure agregar_Ubicacion(IN p_id int, IN p_nombre varchar(100),
                                                    IN p_descripcion varchar(3000))
BEGIN
    INSERT INTO Ubicacion (id_Ubicacion, Nombre, Descripcion)
    VALUES (p_id, p_nombre, p_descripcion);

    SELECT id_Ubicacion AS Ubicacion_agregada
    FROM Ubicacion
    WHERE id_Ubicacion = p_id;
END;

